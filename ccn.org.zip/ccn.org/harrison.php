<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>HARRY ON TECH</title>
        <!-- Favicon-->
		<link rel="icon" type="image/x-icon" href="../assets/favicon.ico" />
        <!-- Bootstrap Icons-->
        <link href="css/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="css/cccfamily.css" rel="stylesheet" />
        <link href="css/cssitalic.css" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="css/simpleLightbox.min.css" rel="stylesheet" />
		<!-- Bootstrap Icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
        <!-- SimpleLightbox plugin CSS-->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.css" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
		 <link rel="stylesheet" href="css/popup.css">
	<?php
		function contact_us($array){	
		}
		?>
	  <?php
		$servername = "localhost";
		$username = "root";
		$password = "";
		$db = "Client";
		// Create connection
		$con;
		try{
			$con= mysqli_connect($servername,$username,$password,$db);
			if(!$con){  
				throw new Exception('Connection was Not established');
			}
			else{
				contact_us($_POST);
				if(isset($_POST["name"])) {
					$f_name = $_POST["name"];
					$email = $_POST['email'];
					$phone = $_POST['phone'];
					$text = $_POST['text'];
					
					$to_email = $email;
					$subject = '<b>MESSAGE DELIVERY</b>';
					$message = 'We`ve received your message,we`ll reach back to you as soon as possible';
					$headers = 'From: noreply@ccn.networks';
							//existing email address in our database
					$sql = "SELECT Name FROM Clients WHERE Email = '$email' || Phone='$phone' LIMIT 1" ;
					$check_query = mysqli_query($con,$sql);
					$count_email = mysqli_num_rows($check_query);
					if(($count_email)>1){
						$sql = "update `Clients` set `Name`='$f_name', `Email`='$email', `Phone`='$phone', `Text`='$text'";
						exit();
					} 
					elseif($count_email<1) {	
						$sql = "INSERT INTO `Clients` (`Name`, `Email`, `Phone`, `Text`) VALUES ('$f_name','$email','$phone','$text')";
						mail($to_email,$subject,$message,$headers);
						$run_query = mysqli_query($con,$sql);
						echo('<script>
						Success();
						</script>');
					}	
				}	
			}
		}
		catch(Exception $e) {
			echo 'Message: ' .$e->getMessage();
		}
		?>	
    </head>
    <body id="page-top">
		<!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#page-top">PERSONAL BLOG</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto my-2 my-lg-0">
                        <li class="nav-item"><a class="nav-link"  id="ab" href="#about">ABOUT</a></li>
                        <li class="nav-item"><a class="nav-link"  id="serv" href="#services">SERVICES</a></li>
                        <li class="nav-item"><a class="nav-link" id="port"  href="#portfolio">PORTFOLIO</a></li>
                        <li class="nav-item"><a class="nav-link" href="#Let'sTalk...!" id="contact-us">CONTACT</a></li>
						<li class="nav-item"><a class="nav-link" href="home">PROJECTS</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container px-4 px-lg-5 h-100">
                <div class="row gx-4 gx-lg-5 h-100 align-items-center justify-content-center text-center">
				<div class="profile"><img style="width: 60px;height: 60px;" src="../assets/img/logo.png" alt=""/>
					<p style="color: white;font-weight: bold;"></p></div>
                    <div class="col-lg-8 align-self-end" style="margin-top: -30px;" id="Let'sTalk...!">
                        <h1 class="text-white font-weight-bold"><span style="font-size: 55px;">HARR</span><span style="color:#44F917;font-family:Constantia, 'Lucida Bright', 'DejaVu Serif', Georgia, 'sans-serif';font-size: 60px;margin-top: -10px;">IS</span><span style="color:#E34E0B;font-family:Constantia, 'Lucida Bright', 'DejaVu Serif', Georgia, 'sans-serif';font-size: 60px;">ON</span>  <span style="color: #1F0AD5">TECH</span>NOLOGIES</h1>
                        <hr class="divider" />
                    </div>
                    <div class="col-lg-8 align-self-baseline">
                        <p class="text-white-75 mb-5">Let's get started with Harrison Technologies. The Professional Freelencer embarked in Connecting Community Networks, ensuring equity, awareness and transparency in operations!</p>
                        <a class="btn btn-primary btn-xl" href="#about">Read More</a>
					<div id="separator" style="margin: 30px auto;"><hr></div>
                    </div>
                </div>
            </div>
        </header>
        <!-- About-->
        <section class="page-section bg-primary" id="about">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-8 text-center">
                        <h2 class="text-white mt-0">I've got what you needed!</h2>
                        <hr class="divider divider-light" />
                        <p class="text-white-75 mb-4">I've everything you need to get your new services up and running in no time! Choose one of my open services, free to inquire, and easy to use! No struggle attached! Just Hurry-up with Harrison,a Computer Science Professional; skilled in Web Design,Networking,System Administration & IT Infrastructure,Project Management and Software Development.</p>
                        <a class="btn btn-light btn-xl" href="#services">Get Started!</a>
                    </div>
                </div>
            </div>
        </section>
        <!-- Services-->
        <section class="page-section" id="services">
            <div class="container px-4 px-lg-5">
                <h2 class="text-center mt-0">SERVICES</h2>
                <hr class="divider" />
                <div class="row gx-4 gx-lg-5">
                    <div class="col-lg-3 col-md-6 text-center" >
                        <div class="mt-5" id="se" >
                            <div class="mb-2"><i class="bi-gem fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">SOFTWARE DEVELOPMENT</h3>
                            <p class="text-muted mb-0"><b>My software products are up-to-date through upgration to ensure compatibility & bug-free!</b></p>
<!--							<a href="../home#sd" class="link" style="pointer-events:">Show more</a>-->
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5" id="wd">
                            <div class="mb-2"><i class="bi-laptop fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">WEB DESIGN & DEVELOPMENT</h3>
                            <p class="text-muted mb-0"><b>All Web-technologies,designs & dependencies are kept up-to-date to keep things fresh and working. </b></p>
<!--							<a href="../home#wd" class="link" style="pointer-events:">Show more</a>-->
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5" id="net">
                            <div class="mb-2"><i class="bi-globe fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">CYBERSECURITY & NETWORKING</h3>
                            <p class="text-muted mb-0"><b>The Advanced Network Security,installation & configuration Acts* are in progress!</b></p>
<!--							<a href="../home#net" class="link" style="pointer-events:">Show more</a>-->
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 text-center">
                        <div class="mt-5" id="sa">
                            <div class="mb-2"><i class="bi-person fs-1 text-primary"></i></div>
                            <h3 class="h4 mb-2">SYSTEM ADMINISTRATION</h3>
                            <p class="text-muted mb-0"><b>Is it really to say that your information is safe?, Contact me for more info about info-breach.</b></p>
<!--							<a href="../home#sa" class="link" style="pointer-events:">Show more</a>-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Portfolio-->
        <div id="portfolio">
            <div class="container-fluid p-0">
				<h2 class="text-center mt-0">PORTFOLIO</h2>
                <div class="row g-0">
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/1.jpg" title=" All complete and super-engaging websites are build by Harrison Technologies which utilizes all new UX/UI & Database metrics to fulfill customers' requirements eg: CCN PORTAL">
                            <img style="height: 300px;width: 100%;" class="img-fluid" src="assets/img/portfolio/thumbnails/1.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">WEB DEVELOPMENT</div>
                                <div class="project-name">CCN PORTAL</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/2.jpg" title=" All complete and super-engaging systems are build by Harrison Technologies which utilizes all new UX/UI & Database metrics to fulfill customers' requirements eg: CCN PORTAL">
                            <img style="height: 300px;width: 100%;" class="img-fluid" src="assets/img/portfolio/thumbnails/2.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">SOFTWARE DEVELOPMENT</div>
                                <div class="project-name">SOFTWARE APPLICATIONS</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/3.jpg" title="The Advanced Network Security,installation & configuration Activities are in progress and performed by Harrison.">
                            <img style="height: 300px;width: 100%;" class="img-fluid" src="assets/img/portfolio/thumbnails/3.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">NETWORKING</div>
                                <div class="project-name">COMPUTER NETWORKS</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/4.jpg" title="Harrison Technologies is your only realtime personal saviour towards privacy breach. Contact me to be sorted at your own convinience.">
                            <img  style="height: 300px;width: 100%;" class="img-fluid" src="assets/img/portfolio/thumbnails/4.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">SYSTEM ADMINISTRATION</div>
                                <div class="project-name">CYBER & INFORMATION SECURITY</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/5.jpg" title="Harrison is your proval thinking partner in ensuring that your're confortable by having your work done, rest easy by connecting and getting remote ICT services from me">
                            <img style="height: 300px;width: 100%;" class="img-fluid" src="assets/img/portfolio/thumbnails/5.jpg" alt="..." />
                            <div class="portfolio-box-caption">
                                <div class="project-category text-white-50">ICT SERVICES</div>
                                <div class="project-name">CYBERNETICS</div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-sm-6">
                        <a class="portfolio-box" href="assets/img/portfolio/fullsize/6.jpg" title="Connections to other platforms are made easy to other platforms by Harrison, please get more views and custmomers from this website.">
                            <img style="height: 300px;width: 100%;" class="img-fluid" src="assets/img/portfolio/thumbnails/6.jpg" alt="..." />
                            <div class="portfolio-box-caption p-3">
                                <div class="project-category text-white-50">ADVERTISEMENT & NEWS</div>
                                <div class="project-name">CONNECTIONS</div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Call to action-->
        <section class="page-section bg-dark text-white">
            <div class="container px-4 px-lg-5 text-center">
                <h2 class="mb-4" >Free To Download My CV!</h2>
                <a class="btn btn-light btn-xl" href="../CURRICULUM VITAE.pdf#toolbar=0&navpanes=0&scrollbar=0" type="application/pdf" width="100%" height="600px">Download Now!</a>
				
            </div>
        </section>
        <!-- Contact-->
        <section class="page-section" id="contact" style="background-color: aliceblue;">
            <div class="container px-4 px-lg-5" style="background-color:">
                <div class="row gx-4 gx-lg-5 justify-content-center mb-5">
                    <div class="col-lg-6" style="background-color: aliceblue;box-shadow: 2px 2px 5px 5px rgba(0,1,0,0.15);">
                        <!-- * *  Forms Contact Form * *-->
                         <form id="contactForm" method="POST" action="" autocomplete="off"  name="form">	 
							 <div class="popup">
								 <div class="close-btn">&times;</div>
								 <div class="form">
									 <div class="row gx-4 gx-lg-5 justify-content-center">
										 <div class="col-lg-8 col-xl-6 text-center">
											 <h2 class="mt-0" style="font-size: 20px;font-weight: bold;">Let's Get In Touch!</h2>
											 <hr class="divider" />
											</div>
									 </div>
									  <p class="text-muted mb-5" style="font-weight: bold;"><b>Ready to start venturing into technological world with me? Send me a message and I will get back to you as soon as possible!</b></p>
									 <div class="form-floating mb-3">
										 <input class="form-control" name="name" id="name" type="text" placeholder="Enter your name..." data-sb-validations="required"/>
										 <label for="name">Full name</label> 
										 <div id="namError"></div>
									 </div>
									 <!-- Email address input-->
									 <div class="form-floating mb-3">
										 <input class="form-control" name="email" id="email" type="email" placeholder="ccx@gmail.com" data-sb-validations="required,email"/>
										 <label for="email">Email address</label> 
										 <div id="email_error" ></div>
									 </div>
									 <!-- Phone number input-->
									 <div class="form-floating mb-3">
										 <input class="form-control" name="phone" id="phone" type="tel" placeholder="(+254) 748 730-758 " data-sb-validations="required"/>
										 <label for="phone">Phone number</label> 
										 <div id="pError" > </div> 
									 </div>
									 <!-- Message input-->
									 <div class="form-floating mb-3">
										 <textarea class="form-control" name="text" id="message" type="text" placeholder="Enter your message here..." style="height: 10rem" data-sb-validations="required"></textarea>
										 <label for="message">Message</label>
										 <div id="mess_error" ></div>
									 </div>
									 <!-- Confirm-->
									 <div  class="d-confirm" id="con">
										 <input type="checkbox" class="checkbox" id="checkbox" onchange="Verify()" >
										 <label>confirm before submission</label>
									 </div>
									 <br>
									 <!-- Submit Button-->
									 <div type="submit" class="d-grid" ><button id="Send" disabled class="btn btn btn-primary btn-xl" onClick="Validate()" >Submit</button>
									 </div>
									 <script type="text/javascript" src="js/script.js"></script>
								 </div>
							 </div>
							 <div class="profile">
							 <article id="prof"><img src="assets/img/profile.jpg" alt="assets/img/profile.jpg"></article>
							 </div>
							 <br><br>
							 <div id="recall">
								 <p>This is Musumba Harison.<br>
								    Bsc. Computer Science,<br>
								    SysAdmin, Networks & IT Infrastructure Professional.
								 </p>
							 </div>				 
                        </form>
                    </div>
                </div>
				<div class="ack" id="ack">
							<img src="assets/img/tick2.png" alt="tick.png"/>
							<h3>Thank you..!</h3>
							<p>Your message has been successfully submitted.</p>
							<button type="button" onClick="closeAck()">OK</button>
				</div>
				<div class="very" id="verify">
							<img src="assets/img/tick1.png" alt="tick.png"/>
							<h3>Correct..!</h3>
							<p>Your details is correct...</p>
							<button type="button" onClick="closeVery()">OK</button>
				</div>
				<div class="error" id="error">
							<img src="assets/img/wrong.png" alt="tick.png"/>
							<h3>Error..!</h3>
							<p>Please fill out all fields...</p>
							<button type="button" onClick="closeError()">RE-TRY</button>
				</div>
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-4 text-center mb-5 mb-lg-0">
                        <a href="tel:+254748730758" data-rel="external"><i class="bi-phone fs-2 mb-3 text-muted"></i>
                        <div style="font-size:1Opx;font-weight: 900;color: #0A218E;text-decoration:none;outline: none;">CALL NOW</div></a>
                    </div>
                </div>
            </div>
        </section>
       <!-- footer Start-->
	<footer>
		<!-- container Start-->
		<div class="container">
			<div class="row">
				<div class=" col-12">
					<ul class="ml-auto">
						<li class="nav-item active">
							<a class="nav-link active" href="">Home <span class="sr-only">(current)</span></a>
						</li>
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="#about"> About</a></li>
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="#services">Services </a></li>
<!--
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="../home#testimonials" style="pointer-events:">Testimonials</a></li>
-->
<!--
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="../home#thumbnail" style="pointer-events:">Teams</a></li>
-->
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item" id="contact-us"><a class="nav-link" href="#Let'sTalk...!" >Contact</a></li>
<!--
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="../home/#terms" style="pointer-events:;">Terms & Policies</a></li>
-->
					</ul>
					<p class="text2" style="padding-right:2px;color: #fff">Copyright &copy; <script > document.write(new Date().getFullYear())
                     </script>, All rights reserved.  
					<div style="text-decoration: none;color: #fff;font-size: 14px;text-align: center;font-weight: bold;"> Powered By:
					<a  style="text-decoration: none;color: lawngreen;font-size: 14px;font-weight: bold; pointer-events: none;" href="" target="_blank">Analytic Systems</a></div></p>
				</div>
			</div>
		</div>
		<!-- container Ended-->
	</footer>
	<!--	footer end -->
	 <!-- Core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- SimpleLightbox plugin JS-->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/SimpleLightbox/2.1.0/simpleLightbox.min.js"></script>
      <script src="js/scripts.js"></script>
      
    </body>
</html>
