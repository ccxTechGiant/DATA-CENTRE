
<!doctype html>
<html lang="en"><head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>CCN TECHNOLOGIES</title>
	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans+Condensed:ital,wght@0,300;0,700;1,300&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/main.css">
	<link rel="stylesheet" href="../css/styles.css">
	<style>
		#contactForm{
	margin-left: 300px;
	box-sizing: border-box;
	width: 300px;
	height: 500px;
	}
.form-control{
	background-color:#F9F9F9;
}
	.popup{
/*		margin-top: 180px;*/
		position: absolute;
		top: -50%;
		left: 50%;
		opacity: 0;
		transform: translate(-50%,-50%)scale(0.75);
		width: 600px;
		height: 750px;
		background: url("../context.ccx.scope/images/crop-03.png");
		background-size:cover;
		background-position:center;
		padding: 50px 20px;
		box-shadow: 2px 2px 5px 5px rgba(0,0,0,0.15);
		border-radius: 10px;
		animation:  Ex 3s 1.5s forwards;
		transition: top 0ms ease-in-out 200ms,
			opacity 200ms ease-in-out 0ms,
			transform 20ms ease-in-out 0ms;
	}
	.popup.active{
	top: 50%;
	opacity: 1;
	transform: translate(-50%,-50%)scale(1);
	transition: top 0ms ease-in-out 0ms,
			opacity 200ms ease-in-out 0ms,
			transform 20ms ease-in-out 0ms;
	}
	.popup .close-btn{
		position: absolute;
		top:10px;
		right: 10px;
		width: 20px;
		height: 20px;
		background: #888;
		color: #eee;
		text-align:center;
		line-height: 15px;
		border-radius: 15px;
		cursor: pointer;
	}
	.popup .form h2{
		text-align: center;
		color: #222;
		margin: 10px 0px 20px;
		font-size: 25px;
	}
.form .d-confirm{
	display: inline-flex;
}
.d-confirm label{
	font-size: 12px;
	color: #150A9B;
	font-weight: bold;
}
.d-confirm .checkbox{
	margin: 2px 6px 6px 0px;
	width: 15px;
	height: 15px;
	border-radius: 100%;
}
.ack,.error,.very{
	width: 400px;
	background: #fff;
	border-radius: 6px;
	position: absolute;
	top: 0%;
	left: 50%;
	transform: translate(-50%,-50%)scale(0.1);
	text-align: center;
	padding: 0px 30px 30px;
	color: #333;
	border:1px #000;
	visibility: hidden;
	transition: transform 0.4s,top 0.4s;
}
.open-validate{
visibility: visible;
top: 60%;
transform: translate(-50%,-50%)scale(1);
}
.ack img,.error img,.very img{
	width: 100px;
	margin-top: -50px;
	border-radius: 50%;
	box-shadow: 0 2px 5px rgba(0,0,0,0.5)
}
.ack h3,.error h3, .very h3{
	font-size: 30px;
	font-weight: 500;
	margin: 30px 0 30px;
}
.ack p,.error p,.very p{
	 font-size: 14px;
	font-family: Constantia, "Lucida Bright", "DejaVu Serif", Georgia, "serif";
	font-weight: 900;
}
.ack button,.very button{
	width: 100%;
	margin-top: 50px;
	padding: 10px 0;
	background: #6fd649;
	color: #fff;
	border: none;
	font-size: 18px;
	border-radius: 4px;
	cursor: pointer;
	box-shadow: 0 5px 5px rgba(0,0,0,0.2);
}
.error button{
	width: 100%;
	margin-top: 50px;
	padding: 10px 0;
	background:#F1080C;
	color: #fff;
	border: none;
	font-size: 18px;
	border-radius: 4px;
	cursor: pointer;
	box-shadow: 0 5px 5px rgba(0,0,0,0.2);
}
@media(min-width: 376px){
#contacForm {
  width: 376px;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  border-radius: 0.25rem;
}
	#contactForm #popup{
		width: 360px;
	}
	#popup .text-muted{
		font-size: 14px;
	}
	#popup .form-floating input{
		width: 300px;
	}
}
@media(min-width: 476px){
#contacForm {
  width: 456px;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  border-radius: 0.25rem;
}
	#popup{
		width: 360px;
	}
	#popup .text-muted{
		font-size: 17px;
	}
	#popup .form-floating #name{
		width: 300px;
	}
}
@media(min-width: 576px){
#contacForm {
  width: 506px;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  -webkit-appearance: none;
     -moz-appearance: none;
          appearance: none;
  border-radius: 0.25rem;
}
	#popup{
		width: 500px;
	}
	#popup .text-muted{
		font-size: 17px;
	}
	#popup .form-floating input{
		width: 90%;
	}
}		
@-webkit-keyframes sca {
	0% {
		left: 0
	}
	50% {
		left: -500px
	}
	to {
		left: 0
	}
}

@keyframes sca {
	0% {
		left: 0
	}
	50% {
		left: -500px
	}
	to {
		left: 0
	}
}

@keyframes Bx{
	0%{
		transform: translateY(40rem)
			rotateY(-20deg);
	}
	100%{
		transform: translateY(0)
			rotateY(0);
		opacity: 1;
	}
}
@keyframes Cx{
	0%{
		transform: translateX(100rem)
			rotateX(20deg);
	}
	100%{
		transform: translateX(0)
			rotateX(0);
		opacity: 1;
	}
}
@keyframes Dx{
	0%{
		transform: translateX(40rem)
			rotateX(-20deg);
	}
	100%{
		transform: translateX(0)
			rotateX(0);
		opacity: 1;
	}
}
@keyframes Ex{
	0%{
		transform: translateY(-40rem)
			rotateY(90deg);
	}
	0% {
		top: 0
	}
	50% {
		top: -500px
	}
	to {
		top: 0
	}
	100%{
		transform: translateX(0)
			rotateX(0);
		opacity: 1;
	}
}
</style>

</head>

<body data-spy="scroll">
	<button onclick="topFunction()" id="myBtn" title="Go to top" style="display: block;"><i class="fa fa-arrow-up" aria-hidden="true"></i></button>
	<!-- header start -->
	<header>
		<div class="container">
			<div class="row">
				<div class="col-12">
					<nav class="navbar navbar-expand-lg navbar-light">
						<a class="navbar-brand" href="home" >
							<img src="../assets/img/logo.png" alt="logo" id="img">
						</a>
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
							<span class="navbar-toggler-icon"></span>
						</button>
					</nav>
				</div>
			</div>
		</div>
	</header>
	<!-- header end -->
	<!--	banner start -->
	<div class="banner">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-8 banner-block">
					 <form id="contactForm" method="POST" action="" autocomplete="off"  name="form">
						 <div class="popup">
							 <div class="close-btn">&times;</div>
							 <div class="form">
								 <div class="row gx-4 gx-lg-5 justify-content-center">
									 <div class="col-lg-8 col-xl-6 text-center">
										 <h2 class="mt-0" style="font-size: 20px;font-weight: bold;">SIGN UP</h2>
									 </div>
								 </div>
								 <p class="text-muted mb-5" style="font-weight: bold;">
									 <b>Ready to start venturing into technological world with us? Create your account with us and we will get back to you as soon as possible!</b></p>
								 <div class="form-floating mb-3" style="height: 20px;">
									 <input class="form-control" name="name" id="name" type="text" placeholder="Enter your name..." data-sb-validations="required"/>
									 <label for="name">Full name</label> 
									 <div id="namError"></div>
								 </div>
								 <br>
								 <!-- Email address input-->
								 <div class="form-floating mb-3" style="height: 20px;">
									 <input class="form-control" name="email" id="email" type="email" placeholder="ccx@gmail.com" data-sb-validations="required,email"/>
									 <label for="email">Email address</label> 
									 <div id="email_error" ></div>
								 </div>
								 <br>
								 <!-- Phone number input-->
								 <div class="form-floating mb-3" style="height: 20px;">
									 <input class="form-control" name="phone" id="phone" type="tel" placeholder="(+254) 748 730-758 " data-sb-validations="required"/>
									 <label for="phone">Phone number</label> 
									 <div id="pError" > </div> 
								 </div>
								 <br>
								 <!-- Date of birth-->
								 <div class="form-floating mb-3" style="height: 20px;">
									 <input class="form-control" name="date" id="date" type="date" placeholder="Date of Birth" data-sb-validations="required"/>
									 <label for="date">Date of Birth</label> 
									 <div id="dError" ></div> 
								 </div>
								 <br>
								 <!-- Town input-->
								 <div class="form-floating mb-3" style="height: 20px;">
									 <input class="form-control" name="town" id="town" type="tel" placeholder="Town" data-sb-validations="required"/>
									 <label for="town">Town</label> 
									 <div id="tError" > </div> 
								 </div>
								 <br>
								 <!-- Motive input-->
								 <div class="form-floating mb-3" style="height: 30px;">
									 <textarea class="form-control" name="text" id="message" type="text" placeholder="Enter your message here..." style="height: 5rem" data-sb-validations="required"></textarea><label for="message">Motives</label>
									 <div id="mess_error" ></div>
								 </div>
								 <br>
								 <br>
								 <!-- Confirm-->
								 <div  class="d-confirm" id="con">
									 <input type="checkbox" class="checkbox" id="checkbox" onchange="Verify()" >
									 <label>confirm before submission</label>
								 </div>
								 <br>
								 <!-- Submit Button-->
								 <div type="submit" class="d-grid" >
									 <button id="Send" disabled class="btn btn btn-primary btn-xl" onClick="Validate()" >Submit</button>
								 </div>
							 </div>
						 </div>	 				 
					</form>
					 <script type="text/javascript" src="../js/script.js"></script>
					<div class="ack" id="ack">
						<img src="assets/img/tick2.png" alt="tick.png"/>
						<h3>Thank you..!</h3><p>Thank you for signing up with us...</p>
						<button type="button" onClick="closeAck()">OK</button>
					</div>
					<div class="very" id="verify">
						<img src="assets/img/tick1.png" alt="tick.png"/>
						<h3>Correct..!</h3>
						<p>Your details is correct...</p>
						<button type="button" onClick="closeVery()">OK</button>
					</div>
					<div class="error" id="error">
						<img src="assets/img/wrong.png" alt="tick.png"/>
						<h3>Error..!</h3>
						<p>Please fill out all fields...</p>
						<button type="button" onClick="closeError()">RE-TRY</button>
					</div>
					<!--sign up end-->
				</div>
			</div>
		</div>
	</div>
	<!--	banner end -->
	
	<!-- footer Start-->
	<footer>
		<!-- container Start-->
		<div class="container">
			<div class="row">
				<div class=" col-12">
					<ul class="ml-auto">
						<li class="nav-item active">
							<a class="nav-link active" href="">Home <span class="sr-only">(current)</span></a>
						</li>
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="../profile#about"> About</a></li>
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="../profile#services">Services </a></li>
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="#testimonials">Testimonials</a></li>
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="#thumbnail">Team</a></li>
						<span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="../profile#contact">Contact</a></li>
					    <span><a class="hidden-xs">-</a></span>
						<li class="nav-item"><a class="nav-link" href="#policy">Terms & Policies</a></li>

					</ul>
					<p class="text2">Copyright &copy; <script > document.write(new Date().getFullYear())
                     </script>, All rights reserved. 
					<div class="power" style="color: #fff;font-size: 14px;text-align: center;font-weight: bold;">Powered By:
					<a  style="text-decoration: none;color: lawngreen;font-size: 14px;font-weight: bold; pointer-events: none;" href="" target="_blank">Analytic Systems</a></div></p>
				</div>
			</div>
		</div>
		<!-- container Ended-->
	</footer>
	<!--	footer end -->


	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->
	<script src="js/jquery.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/custom.js"></script>
	<script src="js/validate.js"></script>
	<script src="../js/script.js"></script>

</body>

</html>