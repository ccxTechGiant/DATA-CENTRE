<?php
include "client.php";
if (isset($_POST["name"])) {
	$f_name = $_POST["name"];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$text = $_POST['text'];
	$name = "/^[a-zA-Z ]+$/";
	$emailValidation = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9]+(\.[a-z]{2,4})$/";
	$number = "/^[0-9]+$/";

if(empty($f_name) || empty($email) || empty($phone) || 
	empty($text)){
	echo "<div class='alert alert-warning' style='text-align: center;color:#fff;font-weight:bold;background-color:blue;height:30px;font-size:20px;border-radius:2em;'>
	<a href='../home#contact' class='close' data-dismiss='alert' aria-label='close'>&times;</a><b>Please fill out all fields..!</b>
	</div>";
		exit();
	} else {
		if(!preg_match($name,$f_name)){
		echo "<div class='alert alert-warning' style='text-align: center;color:#fff;font-weight:bold;background-color:blue;height:30px;font-size:20px;border-radius:2em;'>
		<a href='../home#contact' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		<b>this $f_name is not valid..!</b></div>";
		exit();
	}
	if(!preg_match($emailValidation,$email)){
		//echo "<div class='alert alert-warning' style='text-align: center;color:#fff;font-weight:bold;background-color:blue;height:30px;font-size:20px;border-radius:2em;'>
		<a href='../home#contact' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		<b>This $email is not valid..!</b></div>";
		exit();
	}
	
	if(!preg_match($number,$phone)){
		echo "<div class='alert alert-warning' style='text-align: center;color:#fff;font-weight:bold;background-color:blue;height:30px;font-size:20px;border-radius:2em;'>
        <a href='../home#contact' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		<b>Mobile number $phone is not valid</b></div>";
		exit();
	}
	if(!(strlen($phone) >=10) && !(strlen($phone) <= 13)){
		echo "<div class='alert alert-warning' style='text-align: center;color:#fff;font-weight:bold;background-color:blue;height:30px;font-size:20px;border-radius:2em;'>
        <a href='../home#contact' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		<b>Mobile number must be 10 digit</b></div>";
		exit();
	}
	if($text==''){
		echo "<div class='alert alert-warning' style='text-align: center;color:#fff;font-weight:bold;background-color:blue;height:30px;font-size:20px;border-radius:2em;'>
        <a href='../home#contact' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		<b>The message $text is not valid</b></div>";
		exit();
	}
	//existing email address in our database
	$sql = "SELECT Name FROM Clients WHERE Email = '$email' || Phone='$phone' LIMIT 1" ;
	$check_query = mysqli_query($con,$sql);
	$count_email = mysqli_num_rows($check_query);
	if($count_email == 1){
		echo "<div class='alert alert-warning' style='text-align: center;color:#fff;font-weight:bold;background-color:blue;height:30px;font-size:20px;border-radius:2em;'>
        <a href='../home#contact' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
		<b>Email address & phone number already existed, try another address and phone.</b></div>";
		exit();
	} 
	
	elseif($count_email<1) {	
		$sql = "INSERT INTO `Clients` 
		(`Name`, `Email`, `Phone`, `Text`) 
		VALUES ('$f_name','$email','$phone', '$text')";
		$run_query = mysqli_query($con,$sql);
		//if(mysqli_query($con,$sql)){	
		echo "<div  class='alert alert-warning' style='text-align: center;color:#fff;font-weight:bold;background-color:blue;height:50px;font-size:20px;border-radius:2em;margin-top:200px;'>
          <a href='../home#contact' class='close' data-dismiss='alert' aria-label='close'>&times;</a>
				<b>Message Send Successfully...!</b>
			</div>
		";
		//echo "<script> location.href='../index.html#contact'; </script>";
        exit();
	}
	}
	
}
?>