<?php
$servername = "localhost";
$username = "root";
$password = "";
$db = "Client";
// Create connection
$con = mysqli_connect($servername, $username, $password,$db);
// Check connection
if (!$con) {
    die("Connection failed, please retry...: " /*. mysqli_connect_error()*/);
}


?>