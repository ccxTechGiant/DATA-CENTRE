// input validation
var email = document.forms['form']['email'];
var password = document.forms['form']['password'];
var email_error = document.getElementById('email_error');
var email_error1 = document.getElementById('email_error1');
var pass_error = document.getElementById('pass_error');
var pass_error1 = document.getElementById('pass_error1');
var page = document.getElementsByName('form');
var move = document.getElementById('move');
const VeryMail = '/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/';

email.addEventListener('textInput',email_Verify);
password.addEventListener('textInput',pass_Verify);
move.addEventListener('textInput',form_Hide);

form.addEventListener('submit',(e)=>{
	e.preventDefault();	
	validate();	
});

function validate(){
	if(email.value.length===0){
		email.style.border="1px solid red";
		email_error.style.display= "block";
		email.focus;
		return false;
	}
	else if(email.value.length>=1 && email.value.length<8){
		email.style.border="1px solid red";
		email_error1.style.display= "block";
		email_error.style.display= "none";
		email.focus;
		return false;
	}
	else if(password.value.length===0){
		password.style.border="1px solid red";
		pass_error.style.display= "block";
		password.focus;
		return false;
	}
	else if(password.value.length >=1 && password.value.length<8){
		password.style.border="1px solid red";
		pass_error1.style.display= "block";
		pass_error.style.display= "none";
		pass_error1.style.display= "block";
		password.focus;
		return false;
	}
	else if(password.value.length>=8 && email.value.length>=7){
			pass_error.style.display= "none";
			pass_error1.style.display= "none";
		    email_error.style.display="none";
		    email_error1.style.display="none";
		    return location.href='../CCX/blog/Blog.html';
	};
	
}
function email_Verify(){
	if(!isEmail(email)){
		email.style.border="1px solid silver";
		email_error.style.display= "none";
		email_error1.style.display= "block";
		return false ;

	}
	if(email.value.length>=7){
		email.style.border="1px solid silver";
		email_error.style.display= "none";
		email_error1.style.display= "none";

	}
}
function isEmail(email){
	return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email.value);
}
function pass_Verify(){
		if(password.value.length<8){
		password.style.border="1px solid silver";
		pass_error.style.display= "none";
		pass_error1.style.display= "none";
		return true ;
	}
	}
function form_Hide(){
		page.style.display= "none";
	}
