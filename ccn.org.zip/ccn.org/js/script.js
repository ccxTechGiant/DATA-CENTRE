document.querySelector("#contact-us").addEventListener("click",function(){
document.querySelector(".popup").classList.add("active");
});

document.querySelector(".popup .close-btn").addEventListener("click",function(){
document.querySelector(".popup").classList.remove("active");
});


//document.querySelector(".container .row .col-12 #contact-us-more").addEventListener("click",function(){
//	document.querySelector(".popup").classList.add("active");
//});


//document.querySelector("#ab").addEventListener("click",function(){
//document.querySelector(".popup").classList.remove("active");
//});
//document.querySelector("#serv").addEventListener("click",function(){
//document.querySelector(".popup").classList.remove("active");
//});
//document.querySelector("#port").addEventListener("click",function(){
//document.querySelector(".popup").classList.remove("active");
//});

const page = document.getElementById('contactForm');
const name = document.forms['form']['name'];
const email = document.forms['form']['email'];
const phone = document.forms['form']['phone'];
const message = document.forms['form']['text'];
let Timer = 0;

const namError = document.getElementById('namError');
const mess_error = document.getElementById('mess_error');
const email_error = document.getElementById('email_error');
const pError = document.getElementById('pError');

const Name = document.getElementById('name');
const Email = document.getElementById('email');
const Phone = document.getElementById('phone');
const Text = document.getElementById('message');
const confirm = document.getElementById('checkbox');
const Send = document.getElementById("Send");

confirm.addEventListener('checkbox',(e)=>{
	e.preventDefault();
  Verify();
});

page.addEventListener('submit',(e)=>{
  Validate();
	document.querySelector("#ack").addEventListener("click",function(){
		document.querySelector(".ack").classList.add("active");
		confirm.checked===false;
  Success();
	});
});
window.onload = (event) => {
	addEventListener('messageerror', (event) => { 
	let error = document.getElementById("error");
	error.classList.remove("open-validate"); 
	});
};
window.removeEventListener = (event) => {
	let error = document.getElementById("error");
	error.classList.remove("open-validate"); 
};


name.addEventListener('textInput',name_Verify);
phone.addEventListener('textInput',phone_Verify);
email.addEventListener('textInput',email_Verify);
message.addEventListener('textInput',message_Verify);

function Verify(){
	if (confirm.checked===true){
			if(Name.value.length===0){
				name.style.border="1px solid red";
				namError.innerHTML ='Your name is required';
				namError.style.color= "red";
				namError.style.fontSize= "12px";
				namError.style.fontWeight= "700";
				Error();
				return false;
			}
			if(Email.value.length===0){
				email.style.border="1px solid red";
				email_error.innerHTML ='Your email is required';
				email_error.style.color= "red";
				email_error.style.fontSize= "12px";
				email_error.style.fontWeight= "700";
				Error();
				return false ;
			}
			if(Phone.value.length===0){
				phone.style.border="1px solid red";
				pError.innerHTML ='Please type your phone number.';
				pError.style.color= "red";
				pError.style.fontSize= "12px";
				pError.style.fontWeight= "700";
				Error();
				return false ;
			}
			if(Text.value.length===0){
				message.style.border="1px solid red";
				mess_error.innerHTML ='Please type your message before submission...';
				mess_error.style.color= "red";
				mess_error.style.fontSize= "12px";
				mess_error.style.fontWeight= "700";
				Error();
				return false ;
			}
			Verified();
        } 
    }



function Validate(){
	Timer++;
	Success();
	if(Timer===5){
	Timer++;
		if(Timer===8){
		return location.href='../profile.php';	
		}	
	}
}

function name_Verify(){
	if(!isName(Name) && Name.value.length<6){
		name.style.border="1px solid red";
		name.focus;
		namError.innerHTML ='Your name is not valid';
		namError.style.display= "block";
		namError.style.color= "red";
		namError.style.fontSize= "12px";
		namError.style.fontWeight= "700";
		return false;
	}
	if(Name.value.length>=6){
		name.style.border="1px solid silver";
		namError.style.display= "none";
	}	
}

function phone_Verify(){
	if(!isPhone(Phone) && (Phone.value.length<=9 || Phone.value.length>=14)){
		phone.style.border="1px solid red";
		pError.innerHTML ='Your phone number is not valid';
		pError.style.display= "block";
		pError.style.color= "red";
		pError.style.fontSize= "12px";
		pError.style.fontWeight= "700";
		phone.focus;
		return false ;
	}
	if(isPhone(Phone) && Phone.value.length>=9 && Phone.value.length<=12){
		phone.style.border="1px solid silver";
		pError.style.display= "none";
	}
	return true;
}
function email_Verify(){
	if(!isEmail(Email)){
		email.style.border="1px solid silver";
		email_error.innerHTML ='Your email is not valid';
		email_error.style.display= "block";
		email.focus;
		email_error.style.color= "red";
		email_error.style.fontSize= "12px";
		email_error.style.fontWeight= "700";
		return false ;
	}
	if(email.value.length>=10){
		email.style.border="1px solid silver";
		email_error.style.display= "none";
	}
}

function isEmail(Email){
	return /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(Email.value);
}

function isPhone(Phone){
	return /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/.test(Phone.value);
}

function isName(Name){
	return /^[A-Za-z]*\s{1}[A-Za-z]*$/.test(Name.value);
}
function message_Verify(){
	if(Text.value.length>0){
		message.style.border="1px solid silver";
		mess_error.innerHTML ='';
		mess_error.style.display="none";
		return true;
	}	
}
function Success(){
	let ack = document.getElementById("ack");
	ack.classList.add("open-validate");
	confirm.checked===false;
}
function Error(){
		if(confirm.checked===true && (Name.value.length===0 || Email.value.length===0 || Text.value.length===0 || Phone.value.length===0)){
			let error = document.getElementById("error");
			error.classList.add("open-validate");
			Send.disabled=true;
		}
}
function closeAck(){
	let ack = document.getElementById("ack");
	ack.classList.remove("open-validate");
	confirm.checked===false;
}
function closeError(){
	confirm.checked=false;
	let error = document.getElementById("error");
	error.classList.remove("open-validate"); 
	confirm.checked===false;
}
function Verified(){
	let very = document.getElementById("verify");
	very.classList.add("open-validate");
	Send.disabled=false;
	Name.enabled=false;
	Email.enabled=false;
    Phone.enabled=false;
	Text.enabled=false;
	confirm.enabled=false;
}
function closeVery(){
	let very = document.getElementById("verify");
	very.classList.remove("open-validate");
	Timer.start();
}
