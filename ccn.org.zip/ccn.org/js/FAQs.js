// input validation
const page = document.getElementById('faqs');
const name = document.forms['form']['name'];
const email = document.forms['form']['email'];
const phone = document.forms['form']['phone'];
const message = document.forms['form']['text'];
/////////////////////////////////////////
const namError = document.getElementById('nError');
const namError1 = document.getElementById('nError1');
const email_error = document.getElementById('email_error');
const email_error1 = document.getElementById('email_error1');
const mess_error = document.getElementById('messError');
const pError = document.forms['form']['phoneE'];
const pError1 = document.forms['form']['phoneE1'];
//////////////////////////////////////////
//const move = document.getElementById('move');

page.addEventListener('submit',(e)=>{
	e.preventDefault();
	
	validate();
});
				
name.addEventListener('textInput',name_Verify);
phone.addEventListener('textInput',phone_Verify);
email.addEventListener('textInput',email_Verify);
message.addEventListener('textInput',message_Verify);
//move.addEventListener('textInput',form_Hide);


function validate(){
	const Name = name.value;
	const Tel = phone.value.trim();
    const Mail = email.value.trim();
	const Text = message.value;

/////////////////////////////////////////
	if(Mail.value.length ===0){
		Mail.style.border="1px solid red";
		email_error.style.display= "block";
		Mail.focus;
		return false;
	}
	else if(Mail.value.length>=1 && email.value.length<8){
		Mail.style.border="1px solid red";
		email_error1.style.display= "block";
		email_error.style.display= "none";
		Mail.focus;
		return false;
	}
	else{
		email_Verify();
	}
	
	
/////////////////////////////////////////////////
	if(Tel.value.length===0){
		Tel.style.border="1px solid red";
		pError.style.display= "block";
		phone.focus;
		return false;
	}
   else if(Tel.value.length >=1 && Tel.value.length<=9){
		Tel.style.border="1px solid red";
		pError1.style.display= "block";
		pError.style.display= "none";
		pError1.style.display= "block";
		phone.focus;
		return false;
	}
	else{
		phone_Verify();
	}
////////////////////////////////////////////////////
	if(Text.value.length >=1){
	message_Verify();	
	}
////////////////////////////////////////////////////
	if(Name.value.length>=7){
		name_Verify();
	}
	
}


/////////name verification
function name_Verify(){
		if(name.value.length>=0 && name.value.length <8){
		name.style.border="1px solid silver";
		namError.style.display= "block";
		namError1.style.display= "block";
		return false ;
	}
	else if(name.value.length>=8){
		name.style.border="1px solid silver";
		namError.style.display= "none";
		namError1.style.display= "none";
		return true ;
	}
	}


/////////message verification
function message_Verify(){
		if(message.value.length<=0 && message.value===''){
		message.style.border="1px solid silver";
		mess_error.style.display= "block";
		return false;
	}
	else if(message.value.length>=1){
		message.style.border="1px solid silver";
		mess_error.style.display= "none";
		return true;
	}
	}
/////////email verification
function email_Verify(){
		if(email.value.length>=8){
		email.style.border="1px solid silver";
		email_error.style.display= "none";
		email_error1.style.display= "none";
		return true ;
	}
	}
/////////phone verification
function phone_Verify(){
		if(phone.value.length>=10 && phone.value.length<=12){
		phone.style.border="1px solid silver";
		pError.style.display= "none";
		pError1.style.display= "none";
		return true ;
	}
	}
//function form_Hide(){
//		page.style.display= "none";
//		return true ;
//	}
